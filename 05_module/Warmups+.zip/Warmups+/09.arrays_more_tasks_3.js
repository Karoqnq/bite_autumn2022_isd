var age =[];
var name =[];

function showMember(){

 name.push(document.getElementById("txtName").value);

 age.push(document.getElementById("txtAge").value);

var memberCount = name.length + " member"

}

function showMinor(){

for (i = 0; i < 18; i++){

}
    
}

function showAdult(){

}